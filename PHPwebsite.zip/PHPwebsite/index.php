<!DOCTYPE html>
<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">					<?php // This section links to an external CSS document which is shared by all of the webpages. This document changes the colour of the background. ?>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;			<?php // This section is the internal CSS for this page, which changes the way the entire webpage appears by modifying layout, colours and fonts on the webpage. ?>
				}
				
			.sidenav {						<?php // Affects the appearance of the navigation bar. ?>
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{							<?php // Affects the appearance of the heading in the navigation bar. ?>
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {							<?php // Affects the appearance of the links in the navigation bar. ?>
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {						<?php // Affects the appearance of the links in the navigation bar when hovered over by the cursor. ?>
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;					<?php // Affects the appearance of the main pages contents. ?>
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">						<?php // this section contains the links to the other webpages which will be displayed in the navigation bar on the side of the screen. ?>

			<h1>Features of PHP </h1>
			<a href="index.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
			
		</div>

		<div class="main">
	
			<?php
			
				// this is the content of the homepage. the homepage includes a brief summary of what php is, as well as explaining the purpose of the site. This section uses the echo command to display text.
				
				echo "<h1>Welcome to Features of PHP</h1>";
				
					echo "<h2>What is this all about then?</h2>";
		
						echo "<p><b>Features of PHP</b> is a project of mine to help my learning of the PHP programming language. This website serves two purposes; To allow me to learn PHP practically by using php in web production myself, and to serve 
						as proof of my understanding and knowledge of the PHP programming language.</p>";
			
					echo "<h2>What is PHP?</h2>";
			
					echo "<p>PHP (standing for PHP: Hypertext Preprocessor) is a scripting language most commonly used for web development. PHP differs from other scripting languages by executing it's code server-side, rather than client-side.
						This means that only the result of the executed code is sent to the client-side, rather than the entire code. PHP is simple to use and is great for beginners, but also contains lots of advanced features that would not be
						available in standard HTML, making it great for more experienced programmers to use to make advanced web-creations.</p>";	
			
					echo "<h2>Why use PHP over alternatives?</h2>";
				
					echo "<ul>
							<li><b>Beginner Friendly</b> - Because of it's nature of being embedded into HTML files, any beginner with a knowledge of html can begin modifying their html to contain elements of PHP.</li>
							<li><b>Designed for Web Development</b> - PHP is specifically designed for web-applications, making it more suited for the task than rival languages. </li>
							<li><b>Hosting Availability</b> - All major web host providers support PHP, making it easy to find a web host to use.</li> 
							<li><b>Open-Sourced</b> - All files needed to run PHP are open and free to download and use.</li>
							<li><b>Case-Sensitivity</b> - Only variables in PHP are case-sensitive, making overall usage of PHP much easier and quicker to use.</li>
						</ul>";
						
			
			?>
			
			<?php
				include_once "footer.php";			// This section is an include statement that will include the contents of footer.php (which contain the footer at the bottom of the webpage) into this webpage. 
			?>
			
		</div>

	</body>
	</html>