<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<style>	</style>
	</head>
	
	<body>
	<?php	
	
	// The contents of this PHP document will appear in all webpages, through the use of the include_once() function.
	
	echo "<p>___________________________________________________________________________________________________________________________</p>";
	echo "<p>Sam Bendall 2019</p>";
	?>
	</body>
	

	
</html>