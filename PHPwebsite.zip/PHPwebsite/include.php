<!DOCTYPE html>
<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;
				}
				
			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">

			<h1>Features of PHP </h1>
			<a href="homepage.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
			
		</div>

		<div class="main">
	
			<?php
			echo "<h2>Include Function</h2>";
			
			echo "<p><i>Include() and Require()</i> are two similar functions that can be used to copy the contents from one PHP file and insert them into another. The one major difference between Include and Require is that
			if the PHP file that is called upon is not available, the Include function will display an error message, whilst the require function will cause a fatal error and shut the webpage down. These functions are useful as 
			they can be used to duplicate elements across multiple webpages, by having those elements be in their own web page. </p>";

			echo "<p><i>The Include_Once()</i> command analyses the code for an included PHP document before executing; if it finds that that php code has already been executed, it returns with TRUE, preventing it from being
			executed again and thus only displaying the contents of that PHP document once.</p>";
			
			echo "<p>At the bottom of this page, as well as all pages on this site, is a footer. This footer is a seperate php file called 'footer.php', which is then brought into each webpage by using the include_once function. </p>";
			?>
			
			<img src="include.png" width="291" height="69">
			
			<?php
			
			echo "<p>And this is the content of footer.php: </p>";
			?>
			
			<img src="footerphp.png" width="1163" height="289">
			
			<?php
			
			echo "<p>This means that when the function <i>Include_Once</i> is run, it will bring the contents from footer.php into this page, as can be seen below!</p>";
			?>
			
			<?php
				include_once "footer.php";
				?>
			
			
		</div>

	</body>
	</html>