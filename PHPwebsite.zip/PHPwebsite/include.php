<!DOCTYPE html>
<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">					<?php // This section links to an external CSS document which is shared by all of the webpages. This document changes the colour of the background. ?>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;			<?php // This section is the internal CSS for this page, which changes the way the entire webpage appears by modifying layout, colours and fonts on the webpage. ?>
				}
				
			.sidenav {						<?php // Affects the appearance of the navigation bar. ?>
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{							<?php // Affects the appearance of the heading in the navigation bar. ?>
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {							<?php // Affects the appearance of the links in the navigation bar. ?>
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {						<?php // Affects the appearance of the links in the navigation bar when hovered over by the cursor. ?>
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;					<?php // Affects the appearance of the main pages contents. ?>
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">						<?php // this section contains the links to the other webpages which will be displayed in the navigation bar on the side of the screen. ?>

			<h1>Features of PHP </h1>
			<a href="index.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
			
		</div>

		<div class="main">
	
			<?php
			echo "<h2>Include Function</h2>";			// As an example of the include function is already in use at the bottom of this webpage, as well as all others, I used that as the example here.
			
			echo "<p><i>Include() and Require()</i> are two similar functions that can be used to copy the contents from one PHP file and insert them into another. The one major difference between Include and Require is that
			if the PHP file that is called upon is not available, the Include function will display an error message, whilst the require function will cause a fatal error and shut the webpage down. These functions are useful as 
			they can be used to duplicate elements across multiple webpages, by having those elements be in their own web page. </p>";

			echo "<p><i>The Include_Once()</i> command analyses the code for an included PHP document before executing; if it finds that that php code has already been executed, it returns with TRUE, preventing it from being
			executed again and thus only displaying the contents of that PHP document once.</p>";
			
			echo "<p>At the bottom of this page, as well as all pages on this site, is a footer. This footer is a seperate php file called 'footer.php', which is then brought into each webpage by using the include_once function. </p>";
			?>
			
			<img src="include.png" width="291" height="69">
			
			<?php
			
			echo "<p>And this is the content of footer.php: </p>";
			?>
			
			<img src="footerphp.png" width="1163" height="289">
			
			<?php
			
			echo "<p>This means that when the function <i>Include_Once</i> is run, it will bring the contents from footer.php into this page, as can be seen below!</p>";
			?>
			
			<?php
				include_once "footer.php";			// This section is an include statement that will include the contents of footer.php (which contain the footer at the bottom of the webpage) into this webpage. As it is an include_once statement, this means that even if it were called upon multiple times, it would only display the contents of footer.php once. 
				?>
			
			
		</div>

	</body>
	</html>