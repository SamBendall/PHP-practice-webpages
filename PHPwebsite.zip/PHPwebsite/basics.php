<!DOCTYPE html>
<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">					<?php // This section links to an external CSS document which is shared by all of the webpages. This document changes the colour of the background. ?>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;			<?php // This section is the internal CSS for this page, which changes the way the entire webpage appears by modifying layout, colours and fonts on the webpage. ?>
				}
				
			.sidenav {						<?php // Affects the appearance of the navigation bar. ?>
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{							<?php // Affects the appearance of the heading in the navigation bar. ?>
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {							<?php // Affects the appearance of the links in the navigation bar. ?>
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {						<?php // Affects the appearance of the links in the navigation bar when hovered over by the cursor. ?>
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;					<?php // Affects the appearance of the main pages contents. ?>
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">						<?php // this section contains the links to the other webpages which will be displayed in the navigation bar on the side of the screen. ?>

			<h1>Features of PHP </h1>
			<a href="index.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
			
		</div>

		<div class="main">
	
		<?php

			echo "<h2>PHP Basics</h2>";						// This page covers the basic tools, statements and functions used in PHP. To demonstrate these, I have created examples of each which are then displayed in the text and images of the webpage.
			
			echo "<p>As well as more complex features, PHP has many simpler features that allow to to function and perform actions.</p>";
			
			echo "<h3>Echo & Print Statements</h3>";
			
				echo "<p>There are two main statements used to generate and output in PHP. These are the Echo and Print statements. Both statements are very similar, and do the same task, but the differences between the two are
				minimial; One difference is that an echo statement has a return value of 0, whilst a print statement has a return value of 1. This allows the print statement to be used in expressions. Another is that echos can take
				multiple parameters (even though this is almost never used) whilst a print statement can only have one argument assigned to it at a time. However, echo statements seem to be more common than print statements. </p>";
			
				echo "<p>This entire page was outputted using the echo statement!</p>";
				
		?>
		
			<img src="echo.png" width="344" height="31">
		
		<?php
		
			echo "<h3>Variables</h3>";
			
				echo "<p>Variables are used to store information. Whilst variables can contain different types of data, unlike other programming languages the type of data stored in the variable does not need to be declared when 
				creating the variable. Variable names are also case sensitive, unlike most coding in PHP, which is vital as otherwise the wrong data value could be displayed. Once defined, a variable can be changed through the use of
				functions. To declare a variable, we must choose a name for the variable and attatch it to a $ sign, and set a value to it as so; </p>";
				
				$txt = "This is a String Variable!";						// For the examples of variables, I have declared 3 variables; two with a numerical value (x & y) and one with a string value.		
	
				$x = 5;
				$y = 3;			
				
		?>
				
			<img src="numvar.png" width="88" height="48">
				
		<?php
				
				echo "<p>Variable x is $x , whilst variable y is $y .</p>";   	// This will display the value of the variables within a paragraph of text.
				
		?>
				
			<img src="outputvar.png" width="489" height="33">	
				
		<?php
				
				echo "<p>With the variables declared, we can use them in a variety of ways to display the information stored in them, including running calculations based on the numbers stored in multiple variables, like so;</p>";
				
				echo "x + y = ";	
				echo $x + $y;								//This section shows how variables with a numerical value can be used in calculations, so I have run a simple calculation with variables x & y. 
				echo "<p></p>";
				
		?>
				
				<img src="addition.png" width="117" height="24">
				
		<?php
				
				echo "<p>In addition to integers, a variable can store lots of different types of data, including text and strings. In the example below, the variable '$txtvar' contains text, which when outputted will display the text
				stored in the variable.</p>";
				
				echo "Variable txt reads: " ;
				echo $txt ;								// This simply displays the value of variable txt.
				echo "<p></p>";
				
		?>
				
				<img src="txtvar.png" width="308" height="37">
				<img src="outputtxtvar.png" width="292" height="46">
				
		<?php
				
				echo "<p>Although variables can be declared anywhere inside PHP, where a variable can be accessed depends on where the variable is declared. If a variable is declared outside of a function, it can only be accessed outside
				of functions. However, if the variable is declared inside a function, then it can only be accessed and used inside that variable.</p>";
			
			echo "<h3>Constants</h3>";
			
				echo "<p>Constants are similar to variables, except unlike variables, they cannot be changed at all. To declare a constant, you use the <i>Define()</i> function, like so;</p>";
				
				Define ("constant", "This is a constant!");			// Whilst I was unable to display it with the example, this constant cannot be modified once it is defined, and so will always remain the same value.
				echo constant;
				echo "<p></p>"
		?>
			
			<img src="constant.png" width="365" height="42">
			
		<?php			
		
			echo "<h3>Arrays</h3>";
			
			echo "<p>An array is a variable that can hold more than one value at a time. Arrays can be useful when you have	a large list of items which each have different values associated with them.
			Rather than creating variables for each induvidual value, you can instead assign them all into a single variable, then call upon the specific values as needed by refering to a unique index. 
			There are 3 main types of array, that differ by having a different index value. These are: </p>";
			
			echo "<ul>
					<li><b>Indexed Arrays</b> - Arrays that have a numerical index.</li>
					<li><b>Associative Arrays</b> - Arrays that have names instead of index numbers.</li>
					<li><b>Multidimensional Arrays</b> - Arrays that use a mix of names and index numbers.</li>			
			</ul>";
			
			echo "<p>To create an array, we use the <i>Array()</i> function. In this example, an index array has been created and the values assigned to their index numbers; this can be done
			automatically by the function, or manually by the user. the name of the array is <i>animals</i>, and there are 3 values assigned to it. I can then call upon these values in an echo statement
			by using their index number, so that I can display any specific value.</p>";
			
			$animals = array("Lions", "Tigers", "Bears");							// To demonstrate arrays, I created a simple array with 3 text values. The array is declared, and then the different values are placed within the brackets of the array function.
			
			echo "".$animals[0].", ".$animals[1]." and ".$animals[2]."- Oh My!";
			
			echo "<p></p>"
			
			?>
			
			<img src="array.png" width="576" height="75">
			
			<?php
			
			
			echo "<h3>Functions</h3>";
				echo "<p>Functions are lines of code used to carry out specific tasks. PHP has many built-in functions, some of which (Array, Include, Etc.) are covered on this website. however, these are not the only functions
				available in PHP; The user can also create their own functions that perform a task chosen by the user. To do this, we use the <i>function</i> statement, and declare the name of the function as well as the code to be 
				executed by that function. In this example, we are going to make a simple function that echos some text when executed, however functions can be much more complex and can be used for many different reasons.</p>";
			

			function examplefun() {
				echo "<p><i>This is the output of my function!</i></p>";	// for this example, I created a simple function that, when declared, would echo a small sentence. This was done by using the function statement.
			} 
			examplefun();
			
			?>
			
			<img src="function.png" width="406" height="112">
			
			<?php
	
			

			echo "<h3>Loops</h3>";
			
				echo"<p>Loops in PHP do exactly what they sound like; they loop through a specific segment of code until a certain criteria is met, which helps as it can reduce the overall code required in a document. There are
				2 main types of Loops, these being <b>While Loops</b> and <b>For Loops</b>. While Loops will continue to loop through the code whilst a certain condition is true, whereas a For Loop will do it for a specific number
				of times.</p>";
				
				echo "<h4>While Loops</h4>";
				echo "<p>In this example, I have created a while loop that repeats while the variable y (declared earlier in the document with a value of 3) is equal or less than 10. However, each time it loops, it adds an additional
				1 to the value of y. This means that the message will be displayed 8 times before the statement is no longer true, at which point the loop will end.</p>";
				
					while($y<= 10) {
						echo "This message will repeat while variable y is equal to or less than 10. <br>";				// In this example, a while loop has been created. This loops through the code until the value of variable y is 10.
					$y++;		// this line of code means that the value of variable y will increase by 1 during every loop. This means that after a certain number of loops, the value of variable y will equal 10 and the criteria above will be met, thus ending the loop.
					}
				echo "<p></p>";
			?>
			
					<img src="whileloop.png" width="741" height="61">
			
			<?php
			
				echo "<h4>For Loops</h4>";
				echo "<p>In this example, variable z is set to 1, and the for loop has been set so that it adds 1 to the value of z every time that it loops. This means it will take 10 loops for the value of z to reach 10, 
				at which point the loop will terminate.</p>";

					for ($z = 1; $z <= 10; $z++) {		// In this for loop, a variable must be created for the loop, with both a set current value and a value at which the loop will end. This means that I can decide exactly how many times it will loop for. 
						echo "This message will repeat 10 times because this was chosen for the loop. <br>";
					} 
				echo "<p></p>";
			?>
			
			<img src="forloop.png" width="720" height="58">
			
			<?php
			
	
		include_once "footer.php";			// This section is an include statement that will include the contents of footer.php (which contain the footer at the bottom of the webpage) into this webpage. 
		?>
						
		</div>

	</body>	
</html>

		