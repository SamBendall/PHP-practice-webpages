<!DOCTYPE html>

<?php

$cookie_name = "Example Cookie";													// In this section, a cookie named example cookie has been set to last for 30 days. (86400 = the number of seconds in a day).
setcookie($cookie_name, time() + (86400 * 30), "=/");						// although additional variables can be set, I have chosen to just set a name for the cookie ($cookie_name). I have also set the time the cookie will last for, as required.
?>

<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">					<?php // This section links to an external CSS document which is shared by all of the webpages. This document changes the colour of the background. ?>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;			<?php // This section is the internal CSS for this page, which changes the way the entire webpage appears by modifying layout, colours and fonts on the webpage. ?>
				}
				
			.sidenav {						<?php // Affects the appearance of the navigation bar. ?>
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{							<?php // Affects the appearance of the heading in the navigation bar. ?>
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {							<?php // Affects the appearance of the links in the navigation bar. ?>
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {						<?php // Affects the appearance of the links in the navigation bar when hovered over by the cursor. ?>
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;					<?php // Affects the appearance of the main pages contents. ?>
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">						<?php // this section contains the links to the other webpages which will be displayed in the navigation bar on the side of the screen. ?>

			<h1>Features of PHP </h1>
			<a href="index.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
			
		</div>

		<div class="main">
	
			<?php	
			echo "<h2>Cookies in PHP</h2>";
			echo "<p>Cookies are used on lots of websites to identify users for various purposes. A cookie is a file that embeds itself into a user's device when they access a webpage. When that user accesses the page again,
			the cookie will be sent back to the server, notifying it of a returning device. In PHP, we can create cookies and use them to collect information from a user. To do this, we use the <i>setcookie()</i> function.</p>";
			
			echo "<p>In this example, we have created a cookie using the <i>set_cookie</i> function. This cookie is named example_cookie, and should automatically be set when the webpage loads. If this is the case, a notification
			saying it has been set will be displayed. If not, a notification saying it has not will be displayed instead.</p>";
			
			if(!isset($_COOKIE[$cookie_name])) {
				echo "Cookie '" . $cookie_name . "' is set!<br>";			// this if/else statement will display different messages depending on the cookie-setting being successful or not.
			} else {
				echo "Cookie named '" . $cookie_name . "' is not set!";
				}
				
			echo "<br>";
			?>
			
			<img src="cookie.png" width="443" height="62">
			
			<?php
				include_once "footer.php";			// This section is an include statement that will include the contents of footer.php (which contain the footer at the bottom of the webpage) into this webpage. 
				?>
			
			
		</div>

	</body>
	</html>