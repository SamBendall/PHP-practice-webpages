<!DOCTYPE html>

<?php

$cookie_name = "Example Cookie";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "=/");
?>

<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;
				}
				
			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">

			<h1>Features of PHP </h1>
			<a href="homepage.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
			
		</div>

		<div class="main">
	
			<?php	
			echo "<h2>Cookies in PHP</h2>";
			echo "<p>Cookies are used on lots of websites to identify users for various purposes. A cookie is a file that embeds itself into a user's device when they access a webpage. When that user accesses the page again,
			the cookie will be sent back to the server, notifying it of a returning device. In PHP, we can create cookies and use them to collect information from a user. To do this, we use the <i>setcookie()</i> function.</p>";
			
			echo "<p>In this example, we have created a cookie using the <i>set_cookie function. This cookie is named example_cookie, and should automatically be set when the webpage loads. If this is the case, a notification
			saying it has been set will be displayed. If not, a notification saying it has not will be displayed instead.</i></p>";
			
			if(!isset($_COOKIE[$cookie_name])) {
				echo "Cookie '" . $cookie_name . "' is set!<br>";
			} else {
				echo "Cookie named '" . $cookie_name . "' is not set!";
				}
				
			echo "<br>";
			?>
			
			<img src="cookie.png" width="570" height="66">
			
			<?php
				include_once "footer.php";
				?>
			
			
		</div>

	</body>
	</html>