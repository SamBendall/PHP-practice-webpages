<!DOCTYPE html>
<html>
	<head>
		<title> Features of PHP </title>
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		
			body {
				font-family: "Arial", sans-serif;
				}
				
			.sidenav {
				height: 100%;
				width: 200px;
				position: fixed;
				z-index: 1;
				top: 0;
				left: 0;
				background-color: #111;
				overflow-x: hidden;
				padding-top: 20px;
				}
				
			.sidenav h1{
				padding: 6px 16px 6px 16px;
				text-decoration: none;
				font-size: 28px;
				color: white;
				}
				
			.sidenav a {
				padding: 6px 8px 6px 16px;
				text-decoration: none;
				font-size: 18px;
				color: #818181;
				display: block;
				}
	
			.sidenav a:hover {
				color: #f1f1f1;
				}

			.main {
				margin-left: 200px;
				margin-top: 43px;
				font-size: 22px;
				padding: 0px 10px;
				}
		</style>

	</head>
	
	<body>
		<div class="sidenav">

			<h1>Features of PHP </h1>
			<a href="homepage.php">Homepage</a>
			<a href="basics.php">PHP Basics</a>
			<a href="cookies.php">Cookies in PHP</a>
			<a href="dateandtime.php">Date & Time</a>
			<a href="include.php">Include</a>
			
		</div>

		<div class="main">
	
			<?php
			

				echo "<h2>Date & Time</h2>";
			
					echo "<p>PHP contains functions to display the date and time on a webpage, as well as other functions that utilise date and time.</p>";
				
				echo "<h3>Getting a simple Date</h3>";
				
					echo "<b>Today's date is: </b>" . date("<b>l d M Y</b>");
				
					echo "<p>To get a simple date, you use the function <i>date()</i>. As with the example above, this will display the current date. When using the date function, it is vital that the format is inputted, otherwise
					the function will not work. However, the formatting available for this function is relaxed, allowing the user to display the date in their own prefered way.</p>";
				
					echo "<p>When formatting the date, 4 main characters are used to represent the parts of the date, and the way those characters are used can change the way the date is displayed. These characters are;</p>";
				
					echo "<ul>
							<li>d - Represents the day of the month (0-31)</li>
							<li>m - Represents the month (0-12). Alternatively, using a capital M instead displays the month as the first 3 letters. </li>
							<li>y - Represents the year in 2 digits. Alternatively, using a captical Y instead displays the year in 4 digits.</li>
							<li>l - Represents the day of the week. </li>
					</ul>";
				
					echo "<p>Additionally,  a '.', '/', '-' or blank space can be placed in between the characters for additional formatting purposes.</p>";
				
					echo "<p> for the example above, the date was formatted as so:</p>";
			?>
				<img src="date_code.png" width="420" height="35">
			<?php
				
					echo "<p>In the example above, I have formatted the date so that when it is executed it appears as <i>Weekday, Day, Month (3 Letters), Year (4 Digits).</i>Alternatively, I could have displayed the date without the weekday,
					or with the day of the month first. I have not included additional formatting.</p>";
				
					echo "<h3>Getting a simple Time</h3>";
				
					echo "<b>The time is: </b>" . date("<b>h.i.sa</b>");
				
					echo "<p>As with the date, we use the </i>date()</i> function to get the time as well. The difference is the characters used, which display the hours, minutes and seconds rather than dates.
					The output will display the time at which the page was loaded.</p>";
				
					echo "<p>The characters used in loading the time are;</p>";
				
					echo "<ul>
							<li>h- Represents the hour on a 12 hour clock. Alternatively, a capital H can be used, which will display the hours on a 24 hour clock instead.</li>
							<li>i - Represents minutes (0-59). </li>
							<li>s - Represents seconds (0-59).</li>
							<li>a - Represents AM or PM. </li>
					</ul>";
					echo "<p> for the example above, the time was formatted as so:</p>";
			?>
					<img src="time_code.png" width="420" height="35">
			<?php
					
					echo "<h3>Time Zones</h3>";
				
					echo "<p>Sometimes the time displayed may be incorrect, due to the server being either in a different country or set for a different time. When this happens, it is possible to change the timezone so that the correct
					time is displayed. </p>";
				
					echo "<p>To change the timezone, we use the function <i>date_default_timezone_set()</i>. In the brackets, a location, such as a city or country, or timezone can be entered. This then sets the time zone when displaying the time on a webpage
						to the timezone chosen by the function.</p>";
				
					date_default_timezone_set("London");
				
			?>
						<img src="time_code.png" width="306" height="35">
			<?php
					include_once "footer.php";
			?>
		</div>

	</body>
	</html>